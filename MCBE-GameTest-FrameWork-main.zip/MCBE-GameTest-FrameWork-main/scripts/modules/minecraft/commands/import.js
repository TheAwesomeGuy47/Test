//Please make sure to import your custom command file here
import './test/ping.js';

import './information/help.js';
import './misc/home.js';
import './private/eval.js'

import './misc/sell.js';